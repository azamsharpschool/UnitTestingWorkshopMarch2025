//
//  String+ExtensionsTests.swift
//  OuluBankR1Tests
//
//  Created by Mohammad Azam on 2/15/25.
//

import Testing
@testable import OuluBankR1

struct String_ExtensionsTests {

   

}
