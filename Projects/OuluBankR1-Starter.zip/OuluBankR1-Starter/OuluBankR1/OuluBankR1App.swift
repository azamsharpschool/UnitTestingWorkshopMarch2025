//
//  OuluBankR1App.swift
//  OuluBankR1
//
//  Created by Mohammad Azam on 2/13/25.
//

import SwiftUI

@main
struct OuluBankR1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
