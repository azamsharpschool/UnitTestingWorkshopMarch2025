//
//  APRService.swift
//  OuluBankR1
//
//  Created by Mohammad Azam on 2/15/25.
//

import Foundation

struct APRService {
    
    func getAPR(ssn: String) async throws -> Double {
        return 3.142
    }
    
}
